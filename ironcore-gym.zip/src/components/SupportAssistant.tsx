import React, { useState, useEffect, useRef } from 'react';
import { Mic, X, MessageSquare, Send, Loader2, Volume2, CheckCircle } from 'lucide-react';
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';

export function SupportAssistant({ onClose }: { onClose: () => void }) {
  const [mode, setMode] = useState<'voice' | 'text' | 'loading' | 'booking_summary'>('loading');
  const [messages, setMessages] = useState<{role: string, text: string}[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<{goal: string, level: string, visitPreference: string} | null>(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextPlayTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const chatRef = useRef<any>(null);

  const systemInstruction = `You are the AI Voice Support Assistant for IronCore Gym.
Tone: Friendly, professional, confident.
Strict Rules:
- Use ONLY the real business information provided below. Do NOT guess or invent answers.
- If something isn't listed, say you don't know and guide the visitor to book a free session.
- Give short, professional answers (1-3 sentences maximum).
- When a user shows interest in joining or booking, STOP explanation mode and switch to ACTION mode.
- In ACTION mode, ask ONE question at a time. Wait for the user to answer before asking the next question.
- You must collect these 3 details: 1) their fitness goal, 2) their current fitness level, and 3) their preferred time to visit (morning, afternoon, evening).
- Do NOT confirm exact times.
- Once you have collected all three details, call the 'showBookingSummary' function to display the summary on the screen.
Gym Info:
- Prices: ₹499 Day Pass, ₹2,499/month Standard, ₹4,499/month Pro.
- Hours: 5 AM - 11 PM Weekdays, 6 AM - 10 PM Weekends.
- Location: 123 IronCore Street, Near City Centre, Mumbai, Maharashtra 400001.
- Programs/Classes: Powerlifting, HIIT, Olympic Lifting, Mobility.
- Booking: They can book a free intro session with the Standard or Pro plan.`;

  const showBookingSummaryDeclaration: FunctionDeclaration = {
    name: "showBookingSummary",
    description: "Displays a summary of the collected booking details on the screen for the user to confirm.",
    parameters: {
      type: Type.OBJECT,
      properties: {
        goal: { type: Type.STRING, description: "The user's fitness goal." },
        level: { type: Type.STRING, description: "The user's current fitness level." },
        visitPreference: { type: Type.STRING, description: "The user's preferred time to visit (e.g., morning, afternoon, evening)." },
      },
      required: ["goal", "level", "visitPreference"],
    },
  };

  useEffect(() => {
    initVoice();
    return () => {
      cleanup();
    };
  }, []);

  const cleanup = () => {
    if (processorRef.current) {
      processorRef.current.disconnect();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
    }
    activeSourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) {}
    });
  };

  const initVoice = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextRef.current = audioCtx;
      
      const source = audioCtx.createMediaStreamSource(stream);
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const sessionPromise = ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-09-2025",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
          },
          systemInstruction,
          tools: [{ functionDeclarations: [showBookingSummaryDeclaration] }],
        },
        callbacks: {
          onopen: () => {
            setMode('voice');
            setIsRecording(true);
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcm16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                let s = Math.max(-1, Math.min(1, inputData[i]));
                pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
              }
              const buffer = new Uint8Array(pcm16.buffer);
              
              let binary = '';
              for (let i = 0; i < buffer.byteLength; i++) {
                binary += String.fromCharCode(buffer[i]);
              }
              const base64 = btoa(binary);
              
              sessionPromise.then((session: any) => {
                session.sendRealtimeInput({
                  media: { data: base64, mimeType: 'audio/pcm;rate=16000' }
                });
              });
            };
            source.connect(processor);
            processor.connect(audioCtx.destination);
          },
          onmessage: (message: LiveServerMessage) => {
            if (message.serverContent?.interrupted) {
              activeSourcesRef.current.forEach(s => {
                try { s.stop(); } catch (e) {}
              });
              activeSourcesRef.current = [];
              nextPlayTimeRef.current = audioCtx.currentTime;
              setIsSpeaking(false);
            }
            
            if (message.toolCall) {
              const call = message.toolCall.functionCalls.find(c => c.name === 'showBookingSummary');
              if (call) {
                const args = call.args as any;
                setBookingDetails({
                  goal: args.goal,
                  level: args.level,
                  visitPreference: args.visitPreference
                });
                setMode('booking_summary');
                
                // Send a response back to the model so it knows the tool was called
                sessionPromise.then((session: any) => {
                  session.sendToolResponse({
                    functionResponses: [{
                      id: call.id,
                      name: call.name,
                      response: { result: "Summary displayed successfully. Tell the user to review the details on screen and click Confirm." }
                    }]
                  });
                });
              }
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              setIsSpeaking(true);
              playAudioChunk(base64Audio, audioCtx);
            }
          },
          onclose: () => {
            setIsRecording(false);
            setIsSpeaking(false);
          },
          onerror: (err: any) => {
            console.error("Live API Error:", err);
            fallbackToText();
          }
        }
      });
      
      sessionRef.current = sessionPromise;
      
    } catch (err) {
      console.error("Microphone access denied or error:", err);
      fallbackToText();
    }
  };

  const playAudioChunk = (base64Audio: string, audioCtx: AudioContext) => {
    try {
      const binaryString = atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const pcm16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(pcm16.length);
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 0x8000;
      }
      
      const audioBuffer = audioCtx.createBuffer(1, float32.length, 24000);
      audioBuffer.copyToChannel(float32, 0);
      
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      
      if (nextPlayTimeRef.current < audioCtx.currentTime) {
        nextPlayTimeRef.current = audioCtx.currentTime;
      }
      source.start(nextPlayTimeRef.current);
      nextPlayTimeRef.current += audioBuffer.duration;
      
      activeSourcesRef.current.push(source);
      
      source.onended = () => {
        activeSourcesRef.current = activeSourcesRef.current.filter(s => s !== source);
        if (activeSourcesRef.current.length === 0) {
          setIsSpeaking(false);
        }
      };
    } catch (err) {
      console.error("Error playing audio chunk", err);
    }
  };

  const fallbackToText = () => {
    cleanup();
    setMode('text');
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    chatRef.current = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction,
        tools: [{ functionDeclarations: [showBookingSummaryDeclaration] }],
      }
    });
    setMessages([{ role: 'assistant', text: 'Hi! I am the IronCore Support Assistant. How can I help you today?' }]);
  };

  const handleSendText = async () => {
    if (!inputText.trim() || !chatRef.current) return;
    
    const userMsg = inputText.trim();
    setInputText('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    
    try {
      const response = await chatRef.current.sendMessage({ message: userMsg });
      
      if (response.functionCalls) {
        const call = response.functionCalls.find(c => c.name === 'showBookingSummary');
        if (call) {
          const args = call.args as any;
          setBookingDetails({
            goal: args.goal,
            level: args.level,
            visitPreference: args.visitPreference
          });
          setMode('booking_summary');
          
          // Send response back
          const toolResponse = await chatRef.current.sendMessage({
            contents: [{
              role: 'user',
              parts: [{
                functionResponse: {
                  id: call.id,
                  name: call.name,
                  response: { result: "Summary displayed successfully." }
                }
              }]
            }]
          });
          setMessages(prev => [...prev, { role: 'assistant', text: toolResponse.text }]);
          return;
        }
      }
      
      setMessages(prev => [...prev, { role: 'assistant', text: response.text }]);
    } catch (err) {
      console.error("Chat error:", err);
      setMessages(prev => [...prev, { role: 'assistant', text: 'Sorry, I encountered an error. Please try again.' }]);
    }
  };

  const handleConfirmBooking = () => {
    setBookingConfirmed(true);
    // In a real app, this would send the data to a backend
    setTimeout(() => {
      onClose();
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-[#141414] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl shadow-brand/20 flex flex-col">
        <div className="p-4 border-b border-white/10 flex justify-between items-center bg-[#1a1a1a]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-brand/20 flex items-center justify-center text-brand">
              {mode === 'voice' ? <Mic className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
            </div>
            <span className="font-display font-bold uppercase tracking-wide text-white">Support Assistant</span>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 flex-1 min-h-[300px] flex flex-col">
          {mode === 'loading' && (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
              <Loader2 className="w-8 h-8 animate-spin text-brand mb-4" />
              <p>Connecting to Voice Assistant...</p>
            </div>
          )}
          
          {mode === 'voice' && (
            <div className="flex-1 flex flex-col items-center justify-center text-center">
              <div className={`w-32 h-32 rounded-full flex items-center justify-center mb-8 transition-all duration-300 ${isSpeaking ? 'bg-brand/20 scale-110 shadow-[0_0_30px_rgba(234,88,12,0.4)]' : 'bg-[#222]'}`}>
                <Volume2 className={`w-12 h-12 ${isSpeaking ? 'text-brand animate-pulse' : 'text-gray-500'}`} />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">
                {isSpeaking ? "Assistant is speaking..." : "Listening..."}
              </h3>
              <p className="text-gray-400 text-sm max-w-[250px]">
                Ask me about memberships, hours, location, or booking a session.
              </p>
              
              <button 
                onClick={fallbackToText}
                className="mt-12 text-sm text-gray-500 hover:text-white transition-colors underline underline-offset-4"
              >
                Switch to text chat
              </button>
            </div>
          )}
          
          {mode === 'booking_summary' && bookingDetails && (
            <div className="flex-1 flex flex-col">
              <h3 className="text-xl font-bold text-white mb-4 text-center">Booking Summary</h3>
              
              {bookingConfirmed ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4">
                  <CheckCircle className="w-16 h-16 text-green-500" />
                  <h4 className="text-lg font-bold text-white">Request Sent!</h4>
                  <p className="text-gray-400">A team member will contact you shortly to confirm availability.</p>
                </div>
              ) : (
                <>
                  <div className="bg-[#222] rounded-xl p-4 space-y-4 mb-6">
                    <div>
                      <span className="text-xs text-brand uppercase font-bold tracking-wider">Fitness Goal</span>
                      <p className="text-white font-medium">{bookingDetails.goal}</p>
                    </div>
                    <div>
                      <span className="text-xs text-brand uppercase font-bold tracking-wider">Current Level</span>
                      <p className="text-white font-medium">{bookingDetails.level}</p>
                    </div>
                    <div>
                      <span className="text-xs text-brand uppercase font-bold tracking-wider">Visit Preference</span>
                      <p className="text-white font-medium">{bookingDetails.visitPreference}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-400 text-center mb-6">
                    Please review your details. A team member will confirm availability.
                  </p>
                  <div className="mt-auto">
                    <button 
                      onClick={handleConfirmBooking}
                      className="w-full bg-brand hover:bg-brand-hover text-white py-3 rounded-sm font-bold uppercase tracking-wide transition-colors"
                    >
                      Confirm Request
                    </button>
                    <button 
                      onClick={() => setMode('voice')}
                      className="w-full mt-3 text-gray-400 hover:text-white py-2 text-sm transition-colors"
                    >
                      Back to Assistant
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
          
          {mode === 'text' && (
            <>
              <div className="flex-1 overflow-y-auto space-y-4 mb-4 max-h-[400px] pr-2">
                {messages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${msg.role === 'user' ? 'bg-brand text-white rounded-tr-sm' : 'bg-[#222] text-gray-200 rounded-tl-sm'}`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-auto">
                <input 
                  type="text" 
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSendText()}
                  placeholder="Type your message..."
                  className="flex-1 bg-[#222] border border-white/10 rounded-full px-4 py-2 text-sm text-white focus:outline-none focus:border-brand transition-colors"
                />
                <button 
                  onClick={handleSendText}
                  className="w-10 h-10 rounded-full bg-brand flex items-center justify-center text-white hover:bg-brand-hover transition-colors shrink-0"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
