import React, { useState } from 'react';
import { 
  Dumbbell, Phone, MapPin, Clock, Check, 
  Users, Trophy, Flame, Star, ArrowRight, Menu, X,
  Instagram, Facebook, Youtube, Twitter, Mic
} from 'lucide-react';
import { SupportAssistant } from './components/SupportAssistant';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0 flex items-center gap-2">
            <Dumbbell className="h-8 w-8 text-brand" />
            <span className="font-display font-bold text-2xl tracking-wider uppercase">IronCore Gym</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">Home</a>
            <a href="#about" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">About</a>
            <a href="#classes" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">Classes</a>
            <a href="#memberships" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">Memberships</a>
            <a href="#location" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">Location</a>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <div className="flex items-center gap-2 text-sm font-bold">
              <Phone className="h-4 w-4 text-brand" />
              <span>+91 98765 43210</span>
            </div>
            <a href="#memberships" className="bg-brand hover:bg-brand-hover text-white px-6 py-2.5 rounded-sm font-bold text-sm uppercase tracking-wide transition-colors">
              Get Free Day Pass
            </a>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-300 hover:text-white">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {isOpen && (
        <div className="md:hidden bg-black border-b border-white/10">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-base font-medium text-white">Home</a>
            <a href="#about" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-base font-medium text-gray-300">About</a>
            <a href="#classes" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-base font-medium text-gray-300">Classes</a>
            <a href="#memberships" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-base font-medium text-gray-300">Memberships</a>
            <a href="#location" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-base font-medium text-gray-300">Location</a>
            <div className="mt-4 pt-4 border-t border-white/10 px-3">
              <div className="flex items-center gap-2 text-white font-bold mb-4">
                <Phone className="h-4 w-4 text-brand" />
                <span>+91 98765 43210</span>
              </div>
              <a href="#memberships" onClick={() => setIsOpen(false)} className="block w-full text-center bg-brand hover:bg-brand-hover text-white px-6 py-3 rounded-sm font-bold text-sm uppercase tracking-wide">
                Get Free Day Pass
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

const Hero = ({ onOpenAssistant }: { onOpenAssistant: () => void }) => {
  return (
    <div className="relative pt-20 pb-32 flex items-center min-h-[90vh]">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2940&auto=format&fit=crop" 
          alt="Bodybuilder lifting weights" 
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-[#0a0a0a]"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mt-12">
        <h1 className="font-display text-6xl md:text-8xl font-bold uppercase tracking-tight text-white mb-6 drop-shadow-lg">
          Build Your <span className="text-brand">IronCore</span>
        </h1>
        <p className="text-xl md:text-2xl text-gray-200 font-medium mb-10 max-w-3xl mx-auto drop-shadow-md">
          Premium Local Strength Gym • Open 5 AM Weekdays
        </p>
        
        <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-4 mb-16">
          <a href="#memberships" className="w-full sm:w-auto bg-brand hover:bg-brand-hover text-white px-8 py-4 rounded-sm font-bold text-lg uppercase tracking-wide transition-colors text-center">
            Join Now – From ₹2,499/month
          </a>
          <button onClick={onOpenAssistant} className="w-full sm:w-auto bg-white text-black hover:bg-gray-200 px-8 py-4 rounded-sm font-bold text-lg uppercase tracking-wide transition-colors flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
            <Mic className="h-5 w-5 text-brand" /> Talk to Support
          </button>
          <a href="#memberships" className="w-full sm:w-auto bg-transparent border-2 border-white text-white hover:bg-white hover:text-black px-8 py-4 rounded-sm font-bold text-lg uppercase tracking-wide transition-colors text-center">
            Try a ₹499 Day Pass
          </a>
        </div>

        <div className="inline-flex flex-wrap justify-center items-center gap-x-8 gap-y-4 bg-black/50 backdrop-blur-sm border border-white/10 rounded-full px-8 py-4 text-sm font-medium text-gray-300">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-brand" />
            <span>500+ Local Members</span>
          </div>
          <div className="hidden sm:block w-1 h-1 rounded-full bg-gray-600"></div>
          <div className="flex items-center gap-2">
            <Star className="h-4 w-4 text-brand fill-brand" />
            <span>4.9/5 on Google</span>
          </div>
          <div className="hidden sm:block w-1 h-1 rounded-full bg-gray-600"></div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-brand" />
            <span>Free Parking</span>
          </div>
          <div className="hidden sm:block w-1 h-1 rounded-full bg-gray-600"></div>
          <div className="flex items-center gap-2">
            <Trophy className="h-4 w-4 text-brand" />
            <span>Serving Mumbai Since 2018</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const Features = () => {
  const features = [
    {
      icon: <Users className="h-10 w-10 text-brand" />,
      title: "Expert Coaches",
      description: "Certified trainers who build personalized programs for real results. Local expertise."
    },
    {
      icon: <Dumbbell className="h-10 w-10 text-brand" />,
      title: "State-of-the-Art Iron",
      description: "Hammer Strength, Rogue, and competition-grade barbells and plates. No wait times."
    },
    {
      icon: <Flame className="h-10 w-10 text-brand" />,
      title: "Real Community",
      description: "Join a supportive local fitness family. Train with like-minded people who lift you up."
    }
  ];

  return (
    <section id="about" className="py-24 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4">Why IronCore</h2>
          <div className="w-24 h-1 bg-brand mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center text-center group">
              <div className="w-24 h-24 rounded-full bg-[#141414] border border-white/5 flex items-center justify-center mb-6 group-hover:border-brand/50 transition-colors">
                {feature.icon}
              </div>
              <h3 className="font-display text-2xl font-bold uppercase mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Classes = () => {
  const classes = [
    {
      title: "Powerlifting",
      desc: "Build raw strength. Squat, Bench, Deadlift focus.",
      img: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=800&auto=format&fit=crop"
    },
    {
      title: "HIIT",
      desc: "High-intensity interval training for maximum burn.",
      img: "https://images.unsplash.com/photo-1534258936925-c58bed479fcb?q=80&w=800&auto=format&fit=crop"
    },
    {
      title: "Olympic Lifting",
      desc: "Master the snatch and clean & jerk.",
      img: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=800&auto=format&fit=crop"
    },
    {
      title: "Mobility",
      desc: "Improve flexibility and prevent injury.",
      img: "https://images.unsplash.com/photo-1552674605-db6ffd4facb5?q=80&w=800&auto=format&fit=crop"
    }
  ];

  return (
    <section id="classes" className="py-24 bg-[#111]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4">Popular Classes</h2>
          <div className="w-24 h-1 bg-brand mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {classes.map((cls, idx) => (
            <div key={idx} className="group relative rounded-xl overflow-hidden aspect-[4/5] bg-black">
              <img src={cls.img} alt={cls.title} className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
              <div className="absolute inset-0 p-6 flex flex-col justify-end">
                <h3 className="font-display text-2xl font-bold uppercase mb-2 text-white">{cls.title}</h3>
                <p className="text-gray-300 text-sm mb-6">{cls.desc}</p>
                <a href="#classes" className="inline-flex items-center gap-2 text-brand font-bold text-sm uppercase tracking-wide group-hover:text-white transition-colors">
                  View Schedule <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  return (
    <section id="memberships" className="py-24 bg-[#0a0a0a] relative">
      <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/concrete-wall.png")' }}></div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4">Membership Plans</h2>
          <div className="w-24 h-1 bg-brand mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="bg-[#141414] border border-white/10 hover:border-brand/50 transition-colors duration-300 rounded-2xl p-8 flex flex-col">
            <h3 className="font-display text-2xl font-bold uppercase text-gray-400 mb-2">Day Pass</h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-5xl font-bold">₹499</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Single Day Access</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Full Gym Access</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>No Commitment</span>
              </li>
            </ul>
            <button className="w-full bg-[#222] hover:bg-[#333] text-white py-4 rounded-sm font-bold uppercase tracking-wide transition-colors">
              Get Started
            </button>
          </div>

          <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border-2 border-brand rounded-2xl p-8 flex flex-col relative transform md:-translate-y-4 shadow-2xl shadow-brand/20">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-brand text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              Most Popular
            </div>
            <h3 className="font-display text-2xl font-bold uppercase text-white mb-2">Standard</h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-5xl font-bold">₹2,499</span>
              <span className="text-gray-400">/month</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex items-start gap-3 text-gray-100">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Unlimited Gym Access</span>
              </li>
              <li className="flex items-start gap-3 text-gray-100">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>1 Free Intro Session</span>
              </li>
              <li className="flex items-start gap-3 text-gray-100">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Access to All Classes</span>
              </li>
              <li className="flex items-start gap-3 text-gray-100">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Cancel Anytime</span>
              </li>
            </ul>
            <button className="w-full bg-brand hover:bg-brand-hover text-white py-4 rounded-sm font-bold uppercase tracking-wide transition-colors">
              Get Started
            </button>
          </div>

          <div className="bg-[#141414] border border-white/10 hover:border-brand/50 transition-colors duration-300 rounded-2xl p-8 flex flex-col">
            <h3 className="font-display text-2xl font-bold uppercase text-gray-400 mb-2">Pro</h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-5xl font-bold">₹4,499</span>
              <span className="text-gray-400">/month</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>All Standard Benefits</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>2 Personal Training Sessions/mo</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Nutrition Plan</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <Check className="h-5 w-5 text-brand shrink-0" />
                <span>Priority Booking</span>
              </li>
            </ul>
            <button className="w-full bg-[#222] hover:bg-[#333] text-white py-4 rounded-sm font-bold uppercase tracking-wide transition-colors">
              Get Started
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const testimonials = [
    {
      name: "Rajesh K.",
      text: "Best gym in Mumbai, lost 10kg in 3 months. The community is amazing and the equipment is top-notch!",
      img: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop"
    },
    {
      name: "Priya S.",
      text: "Switched from a commercial gym to IronCore and never looked back. The 5 AM crew is the best.",
      img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop"
    },
    {
      name: "Amit D.",
      text: "The coaches actually care about your form. Hit a new PR on my deadlift within 2 months of joining.",
      img: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop"
    }
  ];

  return (
    <section className="py-24 bg-[#111]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4">Real Results</h2>
          <div className="w-24 h-1 bg-brand mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <div key={i} className="bg-[#1a1a1a] p-8 rounded-2xl border border-white/5 hover:border-brand/30 transition-colors">
              <div className="flex text-brand mb-4">
                {[...Array(5)].map((_, idx) => <Star key={idx} className="h-5 w-5 fill-current" />)}
              </div>
              <p className="text-gray-300 mb-6 italic">"{t.text}"</p>
              <div className="flex items-center gap-4">
                <img src={t.img} alt={t.name} className="w-12 h-12 rounded-full object-cover" />
                <span className="font-bold text-white">{t.name}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Location = ({ onOpenAssistant }: { onOpenAssistant: () => void }) => {
  return (
    <section id="location" className="py-24 bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold uppercase tracking-tight mb-4">Visit Us</h2>
          <div className="w-24 h-1 bg-brand mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          <div className="grid grid-cols-2 gap-4">
            <img src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=600&auto=format&fit=crop" alt="Gym floor" className="w-full h-full object-cover rounded-xl aspect-square" />
            <img src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?q=80&w=600&auto=format&fit=crop" alt="Weights" className="w-full h-full object-cover rounded-xl aspect-square" />
            <img src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=600&auto=format&fit=crop" alt="Cardio area" className="w-full h-full object-cover rounded-xl aspect-square" />
            <img src="https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?q=80&w=600&auto=format&fit=crop" alt="Equipment" className="w-full h-full object-cover rounded-xl aspect-square" />
          </div>

          <div className="bg-[#141414] rounded-xl border border-white/10 p-8 flex flex-col">
            <div className="w-full h-64 bg-gray-800 rounded-lg mb-8 overflow-hidden relative">
              <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1000&auto=format&fit=crop" alt="Map" className="w-full h-full object-cover opacity-50" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white text-black px-4 py-2 rounded-full font-bold shadow-lg flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-brand" /> IronCore Gym
                </div>
              </div>
            </div>

            <div className="space-y-6 flex-1">
              <div>
                <h3 className="font-display text-2xl font-bold uppercase text-white mb-2">IronCore Gym</h3>
                <p className="text-gray-400 flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-brand shrink-0 mt-0.5" />
                  123 IronCore Street, Near City Centre,<br />Mumbai, Maharashtra 400001
                </p>
              </div>
              
              <div className="text-gray-400 flex items-start gap-3">
                <Clock className="h-5 w-5 text-brand shrink-0 mt-0.5" />
                <div>
                  <p>5 AM - 11 PM Weekdays</p>
                  <p>6 AM - 10 PM Weekends</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
              <button className="bg-[#222] hover:bg-[#333] text-white py-3 rounded-sm font-bold uppercase tracking-wide transition-colors flex items-center justify-center gap-2">
                <MapPin className="h-4 w-4" /> Get Directions
              </button>
              <button onClick={onOpenAssistant} className="bg-brand hover:bg-brand-hover text-white py-3 rounded-sm font-bold uppercase tracking-wide transition-colors flex items-center justify-center gap-2">
                <Mic className="h-4 w-4" /> Talk to Support
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const FooterCTA = () => {
  return (
    <section className="bg-brand py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-display text-3xl md:text-4xl font-bold uppercase tracking-tight text-white mb-8">
          Ready to Get Stronger? Limited New Member Spots This Month
        </h2>
        <form className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto mb-8" onSubmit={(e) => e.preventDefault()}>
          <input 
            type="email" 
            placeholder="Enter your email for exclusive offers" 
            className="flex-1 bg-black/20 border border-white/20 text-white placeholder-white/60 px-6 py-4 rounded-sm focus:outline-none focus:border-white transition-colors"
            required
          />
          <button type="submit" className="bg-black hover:bg-gray-900 text-white px-8 py-4 rounded-sm font-bold uppercase tracking-wide transition-colors whitespace-nowrap">
            Sign Up
          </button>
        </form>
        <div className="flex items-center justify-center gap-2 text-white font-bold text-xl">
          <Phone className="h-6 w-6" />
          <span>+91 98765 43210</span>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-[#050505] py-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-8">
          <div className="flex items-center gap-2">
            <Dumbbell className="h-6 w-6 text-brand" />
            <span className="font-display font-bold text-xl tracking-wider uppercase text-white">IronCore Gym</span>
          </div>
          
          <div className="flex flex-wrap justify-center gap-6 text-sm font-medium text-gray-400">
            <a href="#" className="hover:text-brand transition-colors">Home</a>
            <a href="#about" className="hover:text-brand transition-colors">About</a>
            <a href="#classes" className="hover:text-brand transition-colors">Classes</a>
            <a href="#memberships" className="hover:text-brand transition-colors">Memberships</a>
            <a href="#location" className="hover:text-brand transition-colors">Location</a>
            <a href="#" className="hover:text-brand transition-colors">Contact</a>
          </div>

          <div className="flex items-center gap-4">
            <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Instagram className="h-5 w-5" /></a>
            <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Facebook className="h-5 w-5" /></a>
            <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Youtube className="h-5 w-5" /></a>
            <a href="#" className="text-gray-400 hover:text-brand transition-colors"><Twitter className="h-5 w-5" /></a>
          </div>
        </div>
        
        <div className="text-center text-gray-600 text-xs flex flex-col items-center gap-2">
          <p>123 IronCore Street, Near City Centre, Mumbai, Maharashtra 400001</p>
          <p>&copy; {new Date().getFullYear()} IronCore Gym. All Rights Reserved. Privacy Policy | Terms of Service.</p>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  const [showAssistant, setShowAssistant] = useState(false);

  return (
    <div className="min-h-screen font-sans selection:bg-brand selection:text-white">
      <Navbar />
      <main>
        <Hero onOpenAssistant={() => setShowAssistant(true)} />
        <Features />
        <Classes />
        <Pricing />
        <Testimonials />
        <Location onOpenAssistant={() => setShowAssistant(true)} />
        <FooterCTA />
      </main>
      <Footer />
      {showAssistant && <SupportAssistant onClose={() => setShowAssistant(false)} />}
    </div>
  );
}
